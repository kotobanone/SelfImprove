#include <string>

std::string base64_encode(unsigned char const* s,unsigned len);
std::string base64_decode(std::string const& s);